#!/bin/bash
/bin/echo -e "$(/frak/setcolor.sh $(((RANDOM % 65534)+1)) $(shuf -i 33000-65534 -n 1) $(shuf -i 65533-65534 -n 1) $(((RANDOM % 65534)+1)) 100)" | 
socat - udp-datagram:255.255.255.255:56700,broadcast

