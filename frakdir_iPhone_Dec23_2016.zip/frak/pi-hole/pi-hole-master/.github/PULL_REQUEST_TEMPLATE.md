Fixes #[issue number] .

Changes proposed in this pull request:

- 

- 

- 

@pi-hole/gravity
