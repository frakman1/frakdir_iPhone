# Author: Frak Al-Nuaimy 
# email: frakman@hotmail.com

from pyscreenshot import grab
import time
import os
from colour import Color
import lazylights
import sys

#//////////////////////////////////////////////////////////////////////////////////////////////////////////
# GLOBAL DEFINES
#//////////////////////////////////////////////////////////////////////////////////////////////////////////
#HEIGHT         = 1920   #now using image.size[1] dynamically
#WIDTH          = 1200   #now using image.size[0] dynamically
LOOP_INTERVAL  = 2    # how often we calculate screen colour (in seconds)
DURATION       = 2    # how long it takes bulb to switch colours (in seconds)
DECIMATE       = 10   # skip every DECIMATE number of pixels to speed up calculation
#get your unit-unique token from http://developer.lifx.com/ and use it here
TOKEN          = "c590be9f9c544d4418437b774b3a5ab1df1966cd52c9dc3aa0d08f5f5f5b4fa7" 
BULB_NAME      = "Desk1"  # you can use any label you've assigned your bulb here
#//////////////////////////////////////////////////////////////////////////////////////////////////////////

bulbs = lazylights.find_bulbs(expected_bulbs=3,timeout=5)
print bulbs
print len(bulbs)
if (len(bulbs)==0):
    #lazylights.set_power(bulbs, True)
    #time.sleep(1)
    #lazylights.set_power(bulbs, False)
    #time.sleep(1)
    #lazylights.set_power(bulbs, True)
    print "No LIFX bulbs found. Make sure you're on the same WiFi network and try again. Reverting to curl"
    sys.exit(1)
    


# run loop
while True:
	#init counters/accumulators
	red   = 0
	green = 0
	blue  = 0
	
	time.sleep(LOOP_INTERVAL) #wake up ever so often and perform this ...
	#//////////////////////////////////////////////////////////////////////////////////////////////////////////
	# CALCULATE AVERAGE SCREEN COLOUR
	#//////////////////////////////////////////////////////////////////////////////////////////////////////////
	image = ImageGrab.grab()  # take a screenshot
	#print image.size
	
	for y in range(0, image.size[1], DECIMATE):  #loop over the height
		for x in range(0, image.size[0], DECIMATE):  #loop over the width
			#print "\n coordinates   x:%d y:%d \n" % (x,y)
			color = image.getpixel((x, y))  #grab a pixel
			# calculate sum of each component (RGB)
			red = red + color[0]
			green = green + color[1]
			blue = blue + color[2]
			#print red + " " +  green + " " + blue
			#print "\n totals   red:%s green:%s blue:%s\n" % (red,green,blue)
			#print color
	#print(time.clock())
	red = (( red / ( (image.size[1]/DECIMATE) * (image.size[0]/DECIMATE) ) ) )/255.0
	green = ((green / ( (image.size[1]/DECIMATE) * (image.size[0]/DECIMATE) ) ) )/255.0
	blue = ((blue / ( (image.size[1]/DECIMATE) * (image.size[0]/DECIMATE) ) ) )/255.0
	c= Color(rgb=(red, green, blue))  
	#print c
	
	#print "\naverage   red:%s green:%s blue:%s" % (red,green,blue)
	#print "average   hue:%f saturation:%f luminance:%f" % (c.hue,c.saturation,c.luminance)
	print "average  (hex) "+  (c.hex)
	#//////////////////////////////////////////////////////////////////////////////////////////////////////////

	#//////////////////////////////////////////////////////////////////////////////////////////////////////////
	# PROGRAM LIFX BULB WITH COLOUR 
	#//////////////////////////////////////////////////////////////////////////////////////////////////////////
	cmd = " c:\\curl\\curl.exe -u \""+TOKEN+":\" -X PUT -d \"color=" + str(c.hex) + "\" -d \"duration=" +str(DURATION)+ "\" \"https://api.lifx.com/v1beta1/lights/label:"+BULB_NAME+"/color\"" 
	print cmd
	os.system(cmd)
	#lazylights.set_state(bulbs,c.hue*360,c.saturation,c.luminance,5000,3000,False)
	
	

