# Author: Frak Al-Nuaimy 
# email: frakman@hotmail.com

from PIL import ImageGrab
import time
import os
from colour import Color
import lazylights
import sys

import numpy
import pyaudio
import analyse
import math


#//////////////////////////////////////////////////////////////////////////////////////////////////////////
# GLOBAL DEFINES
#//////////////////////////////////////////////////////////////////////////////////////////////////////////
#HEIGHT         = 1920   #now using image.size[1] dynamically
#WIDTH          = 1200   #now using image.size[0] dynamically
LOOP_INTERVAL  = 1    # how often we calculate screen colour (in seconds)
DURATION       = 2    # how long it takes bulb to switch colours (in seconds)
KELVIN         = 0
DECIMATE       = 10   # skip every DECIMATE number of pixels to speed up calculation
#get your unit-unique token from http://developer.lifx.com/ and use it here
TOKEN          = "c590be9f9c544d4418437b774b3a5ab1df1966cd52c9dc3aa0d08f5f5f5b4fa7" 
BULB_NAME      = "all"  # you can use any label you've assigned your bulb here
#//////////////////////////////////////////////////////////////////////////////////////////////////////////
# Initialize PyAudio
pyaud = pyaudio.PyAudio()

# Open input stream, 16-bit mono at 44100 Hz
# On my system, device 2 is a USB microphone, your number may differ.
stream = pyaud.open(
    format = pyaudio.paInt16,
    channels = 1,
    rate = 44100,
    input = True)

	
	
	
bulbs = lazylights.find_bulbs(expected_bulbs=3,timeout=5)
print bulbs
print len(bulbs)
 
while (len(bulbs)==0):
	print "re-trying\n"
	bulbs = lazylights.find_bulbs(expected_bulbs=3,timeout=5)
	print bulbs
	print len(bulbs)
    #lazylights.set_power(bulbs, True)
    #time.sleep(1)
    #lazylights.set_power(bulbs, False)
    #time.sleep(1)
    #lazylights.set_power(bulbs, True)
    #print "No LIFX bulbs found. Make sure you're on the same WiFi network and try again"
    #sys.exit(1)
	
    


# run loop
while True:
	#init counters/accumulators
	red   = 0
	green = 0
	blue  = 0
	
	#time.sleep(0.05) #wake up every so often and perform this ...
   # Read raw microphone data
	rawsamps = stream.read(1024)
    # Convert raw data to NumPy array
	chunk = numpy.fromstring(rawsamps, dtype=numpy.int16)
    # Show the volume and pitch
	data = numpy.array(chunk, dtype=float) / 32768.0
	ms = math.sqrt(numpy.sum(data ** 2.0) / len(data))
	if ms < 0.01: ms = 0.0
	ms = ms *3
	if ms > 0.5: ms =0.5
	print ms
    #return 10.0 * math.log(ms, 10.0)
	
	
	#//////////////////////////////////////////////////////////////////////////////////////////////////////////
	# CALCULATE AVERAGE SCREEN COLOUR
	#//////////////////////////////////////////////////////////////////////////////////////////////////////////
	image = ImageGrab.grab()  # take a screenshot
	#print image.size
	
	for y in range(0, image.size[1], DECIMATE):  #loop over the height
		for x in range(0, image.size[0], DECIMATE):  #loop over the width
			#print "\n coordinates   x:%d y:%d \n" % (x,y)
			color = image.getpixel((x, y))  #grab a pixel
			# calculate sum of each component (RGB)
			'''
			if ((color[0] == 0) and (color[1] == 0) and (color[2] == 0)):
				#print "ignoring"
				color=(0x80,0x80,0x80)
				#continue
			'''	
			red = red + color[0]
			green = green + color[1]
			blue = blue + color[2]
			#print red + " " +  green + " " + blue
			#print "\n totals   red:%s green:%s blue:%s\n" % (red,green,blue)
			#print color
	#print(time.clock())
	red = (( red / ( (image.size[1]/DECIMATE) * (image.size[0]/DECIMATE) ) ) )/255.0
	green = ((green / ( (image.size[1]/DECIMATE) * (image.size[0]/DECIMATE) ) ) )/255.0
	blue = ((blue / ( (image.size[1]/DECIMATE) * (image.size[0]/DECIMATE) ) ) )/255.0
	c= Color(rgb=(red, green, blue))  
	#print c
	
	#print "\naverage   red:%s green:%s blue:%s" % (red,green,blue)
	#print "average   hue:%f saturation:%f luminance:%f" % (c.hue,c.saturation,c.luminance)
	#print "average  (hex) "+  (c.hex)
	#//////////////////////////////////////////////////////////////////////////////////////////////////////////

	#//////////////////////////////////////////////////////////////////////////////////////////////////////////
	# PROGRAM LIFX BULB WITH COLOUR 
	#//////////////////////////////////////////////////////////////////////////////////////////////////////////
	#cmd = " c:\\curl\\curl.exe -u \""+TOKEN+":\" -X PUT -d \"color=" + str(c.hex) + "\" -d \"duration=" +str(DURATION)+ "\" \"https://api.lifx.com/v1beta1/lights/"+BULB_NAME+"/color\"" 
	#print cmd
	#os.system(cmd)
	#lazylights.set_state(bulbs,c.hue*360,(c.saturation),0.5+ms,KELVIN,(500),False)
	lazylights.set_state(bulbs,c.hue*360,(c.saturation),c.luminance,KELVIN,(500),False)
	#bulbs, hue, saturation, brightness, kelvin, fade, raw=False)
	

