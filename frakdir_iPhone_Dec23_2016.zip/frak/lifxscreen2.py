# Author: Frak Al-Nuaimy 
# email: frakman@hotmail.com


import time
import os
from colour import Color
import lazylights
import sys




#//////////////////////////////////////////////////////////////////////////////////////////////////////////
# GLOBAL DEFINES
#//////////////////////////////////////////////////////////////////////////////////////////////////////////
#HEIGHT 	= 1920	 #now using image.size[1] dynamically
#WIDTH		= 1200	 #now using image.size[0] dynamically
LOOP_INTERVAL  = 1    # how often we calculate screen colour (in seconds)
DURATION       = 2    # how long it takes bulb to switch colours (in seconds)
KELVIN	       = 0
DECIMATE       = 10   # skip every DECIMATE number of pixels to speed up calculation
#get your unit-unique token from http://developer.lifx.com/ and use it here
TOKEN	       = "c590be9f9c544d4418437b774b3a5ab1df1966cd52c9dc3aa0d08f5f5f5b4fa7" 
BULB_NAME      = "all"	# you can use any label you've assigned your bulb here
#///////////////////////////////////////////////////////////////////////////////////////////
	
	
	
bulbs = lazylights.find_bulbs(expected_bulbs=3,timeout=5)
#print bulbs
 


	cmd = " c:\\curl\\curl.exe -u \""+TOKEN+":\" -X PUT -d \"color=" + str(c.hex) + "\" -d \"duration=" +str(DURATION)+ "\" \"https://api.lifx.com/v1beta1/lights/"+BULB_NAME+"/color\"" 
	#print cmd
	#os.system(cmd)
	#lazylights.set_state(bulbs,c.hue*360,(c.saturation),0.5+ms,KELVIN,(500),False)
	#lazylights.set_state(bulbs,c.hue*360,(c.saturation),c.luminance,KELVIN,(500),False)
	#bulbs, hue, saturation, brightness, kelvin, fade, raw=False)
	

