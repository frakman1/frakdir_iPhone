#!/bin/sh

now=$(date +"%m_%d_%Y_%H_%M_%S")
echo $now
file=/frak/img/$now.jpg
/usr/bin/camshot -front $file
python /frak/img/imgur-uploader-master/imgur_uploader.py $file

activator send switch-on.com.a3tweaks.switch.cellular-data ; 
activator send switch-on.com.a3tweaks.switch.3g ; 
activator send switch-on.com.a3tweaks.switch.wifi ; sleep 15 && if [[ $(ifconfig en0) != *inet* ]]; then activator send switch-off.com.a3tweaks.switch.wifi; fi; 

source /frak/location.sh

