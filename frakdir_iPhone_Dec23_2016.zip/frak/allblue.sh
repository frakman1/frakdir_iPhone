#!/bin/bash
/bin/echo -e "$(cat /frak/allblue.echo)" | socat - udp-datagram:255.255.255.255:56700,broadcast

