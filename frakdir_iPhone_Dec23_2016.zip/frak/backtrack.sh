#!/bin/sh
activator send libactivator.ipod.previous-track; activator send libactivator.ipod.previous-track

