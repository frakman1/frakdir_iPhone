# lifx-bash

You can use the output of setcolor.sh script in combination with
SoCAT to sent an UDP datagram to LIFX bulbs. This is the way:

```bash
for x in $(seq 1 1000 10000); do                 
    echo -e $(./setcolor.sh 10000 0 0xffff $x 100) | socat -u - udp-datagram:192.168.0.255:56700,broadcast
    sleep 1
done
```

You can monitor LIFX packets with tcpdump:

```
tcpdump -n udp port 57600
```

or with SoCAT using the helper script headerdump.sh: 

```
socat -u udp4-recvfrom:56700,reuseaddr,fork system:'./headerdump.sh'
```

This work is based on two posts of the LIFX community site: 

* https://community.lifx.com/t/building-a-lifx-packet/59
* https://community.lifx.com/t/controlling-lights-with-bash/31
 
the valid ranges for the various parameters are the following:

hue: 0 - 65535
saturation: 0 - 65535
brightness: 0 - 65535
kelvin: 2500 (warm) - 9000 (cool)
This information is also available on this page: http://lan.developer.lifx.com/v2.0/docs/light-messages#section-hsbk

Traditional hue scale goes from 1 to 360 so you need map these values from 0 - 65535. You can do this with this formula: (hue*65535)/360.

Here more examples with colors:

green: (120 * 65535) / 360 = 21845
echo -e $(./setcolor.sh 21845 65535 65535 3500 1000) | socat -u - udp-datagram:192.168.0.255:56700,broadcast
red: (3 * 65535) / 360 = 546
echo -e $(./setcolor.sh 546 65535 65535 3500 1000) | socat -u - udp-datagram:192.168.0.255:56700,broadcast
blue: (240 * 65535) / 360 = 43690
echo -e $(./setcolor.sh 43690 65535 65535 3500 1000) | socat -u - udp-datagram:192.168.0.255:56700,broadcast
The values of saturation and brightness go from 0 to 100 so the formula to map the scale is (value * 65535) / 100.

FrakPhone examples:
hue,saturation,brightness,kelvin,duration(ms)
All green:
# echo -e $(./setcolor.sh 21845 65535 65535 3500 1000) | socat -u - udp-datagram:10.10.10.255:56700,broadcast
alll white:
# echo -e $(./setcolor.sh 10000 0 65535 3500 1000) | socat -u - udp-datagram:10.10.10.255:56700,broadcast

