import lazylights
import time

bulbs = lazylights.find_bulbs(expected_bulbs=None, timeout=3)
lazylights.set_power(bulbs, False)

