#!/bin/bash

for x in $(seq 1 1000 10000); do                 
    echo -e $(./setcolor.sh 10000 0 0xffff $x 100)  | socat - udp-datagram:255.255.255.255:56700,broadcast
    sleep 1
done

