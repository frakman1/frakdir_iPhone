#!/bin/bash
activator send libactivator.speech.synthesize.38FDE0A7-BE6A-491E-929A-CE5F056881C0 && sleep 2 && activator send 
libactivator.lockscreen.dismiss && sleep 2 && activator send com.alexanderben.RadioIn

