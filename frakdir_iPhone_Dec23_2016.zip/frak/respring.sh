#!/bin/bash
killall SpringBoard


