from imgurpython import ImgurClient

import click
import os
try:
    import ConfigParser
except ImportError:
    import configparser as ConfigParser

import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning



def get_config():
    client_id = "73bcab1086a2cdd"
    client_secret = "4f9f6ba711f678c371f0b9d97fbaf97579647175"

    if not (client_id and client_secret):
        return {}

    return {"id": client_id, "secret": client_secret}


@click.command()
@click.argument('image', type=click.Path(exists=True))
def upload_image(image):
    """Uploads an image file to Imgur"""

    config = get_config()

    if not config:
        click.echo("Cannot upload - could not find IMGUR_API_ID or "
                   "IMGUR_API_SECRET environment variables or config file")
        return

    client = ImgurClient(config["id"], config["secret"])

    click.echo('Uploading file {}'.format(click.format_filename(image)))

    response = client.upload_from_path(image)
    #print response['link']
    cmd = "/usr/bin/clsms " + response['link'] + " +16786369690"
    print cmd
    os.system(cmd)
    click.echo('File uploaded - see your image at {}'.format(response['link']))

    try:
        import pyperclip
        pyperclip.copy(response['link'])
    except ImportError:
        print("pyperclip not found. To enable clipboard functionality,"
              " please install it.")

if __name__ == '__main__':
    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
    requests.packages.urllib3.disable_warnings()
    
    upload_image()
