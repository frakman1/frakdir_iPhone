#!/bin/bash
 
# Ubuntu Keyboard settings shortcut:
#  xfce4-screenshooter -r -o "sh /location/to/imgur-uploader.sh"
 
API_KEY=4f9f6ba711f678c371f0b9d97fbaf97579647175
URL=https://api.imgur.com/3/upload
 
RESPONSE=$(curl --cacert ./ca.crt -s -F "key=$API_KEY" -F "image=@$1" $URL )
echo "$RESPONSE"
#echo "$RESPONSE" | grep -o -E "<original>.*</original>" | grep -o -E "http://.*\.png" | xsel -i -b
#notify-send -i info "Screenshot uploaded" "URL has been copied to clipboard"
