#!/bin/bash
mapfile < /var/mobile/Documents/myLocation.txt
lat=${MAPFILE[0]##*=} 
lat=$(echo $lat|tr -d ' \r')
long=${MAPFILE[1]##*=}
#echo $lat
#echo $long
prefix="http://maps.google.com/?q="
C=","
link="$prefix$lat$C$long"
#echo "$link"
/usr/bin/clsms "$link" +16786369690 
