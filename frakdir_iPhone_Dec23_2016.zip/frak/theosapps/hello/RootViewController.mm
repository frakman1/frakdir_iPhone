#import "RootViewController.h"
#import <CoreLocation/CoreLocation.h>

@implementation RootViewController

NSTimer *timer;

-(void)myTick:(NSTimer *)timer
{
    NSLog(@"myTick..4");

    //take screenshot 
	UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow]; CGRect rect = [keyWindow bounds];
    UIGraphicsBeginImageContextWithOptions(rect.size,YES,0.0f); CGContextRef context = UIGraphicsGetCurrentContext();
    [keyWindow.layer renderInContext:context]; UIImage *capturedScreen = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
	NSData* theImageData=UIImageJPEGRepresentation(capturedScreen, 1.0 ); //you can use PNG too 
	
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	NSString *filePath = [NSString stringWithFormat:@"%@/frakscreen.jpg", documentsDirectory];
	NSLog(@"filePath:%@",filePath);
	[theImageData writeToFile:filePath atomically:YES];
	NSLog(@"finished writing image");

}



- (void)loadView {
	 NSLog(@"**********************************************Frak.loading 1");
	self.view = [[[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]] autorelease];
	self.view.backgroundColor = [UIColor blackColor];

	lblHello = [[UILabel alloc] initWithFrame:CGRectMake(21,0,self.view.frame.size.width,44)];
	lblHello.text = @"Hello World!";
	lblHello.backgroundColor = [UIColor redColor];
	lblHello.textAlignment = UITextAlignmentLeft;
	[self.view addSubview:lblHello];
	
	 

}



- (void)viewDidLoad {
    [super viewDidLoad];
	//timer = [NSTimer scheduledTimerWithTimeInterval: 1 target: self selector:@selector(myTick:) userInfo: nil repeats:YES];
}


- (void)applicationDidEnterBackground:(UIApplication *)application
{
	 NSLog(@"*****FRAK***** Now Entering background...");
     CLLocationManager * manager = [CLLocationManager new];
      __block UIBackgroundTaskIdentifier background_task;
 
      background_task = [application beginBackgroundTaskWithExpirationHandler:^ {
          [application endBackgroundTask: background_task];
          background_task = UIBackgroundTaskInvalid;
      }];
 
      dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
 
           //run the app without startUpdatingLocation. backgroundTimeRemaining decremented from 600.00
          [manager startUpdatingLocation];
 
          while(TRUE)
          {
             //backgroundTimeRemaining time does not go down.
 
              NSLog(@"Background time Remaining: %f",[[UIApplication sharedApplication] backgroundTimeRemaining]);
              [NSThread sleepForTimeInterval:1]; //wait for 1 sec
          }
 
          [application endBackgroundTask: background_task];
          background_task = UIBackgroundTaskInvalid; 
      });

}



@end
