@interface RootViewController: UIViewController {
UILabel* lblHello;
}
@end
