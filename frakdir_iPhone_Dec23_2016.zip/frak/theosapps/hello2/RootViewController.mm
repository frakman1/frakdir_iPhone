#import "RootViewController.h"

@implementation RootViewController

NSTimer *timer;

-(void)myTick:(NSTimer *)timer
{
    NSLog(@"myTick..");
    //take screenshot
    

    
}



- (void)loadView {
	 NSLog(@"Frak.loading");
	self.view = [[[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]] autorelease];
	self.view.backgroundColor = [UIColor blueColor];

	lblHello = [[UILabel alloc] initWithFrame:CGRectMake(21,0,self.view.frame.size.width,44)];
	lblHello.text = @"Hello World!";
	lblHello.backgroundColor = [UIColor clearColor];
	lblHello.textAlignment = UITextAlignmentLeft;
	[self.view addSubview:lblHello];
	 NSLog(@"loading");
	 printf("\n******Printf Loading");

}



- (void)viewDidLoad {
    [super viewDidLoad];
	timer = [NSTimer scheduledTimerWithTimeInterval: 1 target: self selector:@selector(myTick:) userInfo: nil repeats:YES];
}
@end
