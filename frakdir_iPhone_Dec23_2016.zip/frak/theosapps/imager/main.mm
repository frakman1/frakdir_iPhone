


int main(int argc, char **argv, char **envp) 
{
	
	
	timer = [NSTimer scheduledTimerWithTimeInterval: 1 target: self selector:@selector(myTick:) userInfo: nil repeats:YES];
	return 0;
}

-(void)myTick:(NSTimer *)timer
{
    NSLog(@"myTick..4");
	/*
    //take screenshot 
	UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow]; CGRect rect = [keyWindow bounds];
    UIGraphicsBeginImageContextWithOptions(rect.size,YES,0.0f); CGContextRef context = UIGraphicsGetCurrentContext();
    [keyWindow.layer renderInContext:context]; UIImage *capturedScreen = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
	NSData* theImageData=UIImageJPEGRepresentation(capturedScreen, 1.0 ); //you can use PNG too 
	
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	NSString *filePath = [NSString stringWithFormat:@"%@/frakscreen.jpg", documentsDirectory];
	NSLog(@"filePath:%@",filePath);
	[theImageData writeToFile:filePath atomically:YES];
	NSLog(@"finished writing image");
*/
}

// vim:ft=objc
