Almpoum
=====================

----------

An incredible screen shot replacement utility. 

> **Features:**
> 
> - Saving screenshots to a custom album.
> - Be prompted with a pop-up asking what you'd like to happen, save, copy to the clipboard, etc.
> - Customizing the screen flash, sound, and much more.
> - Disabling the upload of screenshots to your Photo Stream.
> - And much more!

![A image of the prompt when that appears when taking a screenshot][1]

The tweak can be downloaded *[here][3]*.

----------


  [1]: http://moreinfo.thebigboss.org/moreinfo/almpoum3.jpg
  [2]: http://moreinfo.thebigboss.org/moreinfo/almpoum1.jpg
  [3]: http://moreinfo.thebigboss.org/moreinfo/depiction.php?file=almpoumDp
