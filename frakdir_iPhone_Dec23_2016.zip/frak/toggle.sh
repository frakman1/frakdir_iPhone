#!/bin/sh

TOGGLE=/frak/.toggle

if [ ! -e $TOGGLE ]; then
    touch $TOGGLE
    echo "Turning on Lights"
    source /frak/allon.sh
    #source /frak/allwhite.sh
else
    rm $TOGGLE
    echo "Turning Off Lights"
    source /frak/alloff.sh
fi

