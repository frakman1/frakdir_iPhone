#!/usr/bin/env python

import socket
import time


class cmd2k:

    CMD2K_PORT = 65434

    def __init__(self, stb_ipaddr):
        self.stb_ipaddr = stb_ipaddr

    def __del__(self):
        self.stb_ipaddr = ""


    def cmd(self, cmd):
        print "Trying to Connect to [%s]" %(self.stb_ipaddr)
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((self.stb_ipaddr, self.CMD2K_PORT))
        print "Sending Command [%s]" %(cmd)
        s.send("osdiag " + cmd)
        print "Closing Connection to [%s]" %(self.stb_ipaddr)
        s.close()


if __name__ == "__main__":
    conn = cmd2k("192.168.1.20")
    conn.cmd("fp_pwr")
    #time.sleep(5)
    #conn.cmd("c-")

