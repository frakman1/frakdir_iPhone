#!/bin/bash

/frak/allon.sh && /frak/allwhite.sh

for ((n=0;n<5;n++))
do
 /frak/allred.sh
 sleep 1
 /frak/allwhite.sh
 sleep 1
done

/frak/allwhite.sh


