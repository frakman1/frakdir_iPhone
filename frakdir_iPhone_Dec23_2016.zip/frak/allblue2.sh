#!/bin/bash
curl -u "c590be9f9c544d4418437b774b3a5ab1df1966cd52c9dc3aa0d08f5f5f5b4fa7:" -X PUT -d "color=blue"  
"https://api.lifx.com/v1beta1/lights/all/color" --cacert ./curl-ca-bundle.crt 


