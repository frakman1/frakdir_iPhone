import lazylights
import time

bulbs = lazylights.find_bulbs(expected_bulbs=None, timeout=3)
print bulbs
lazylights.set_power(bulbs, True)
lazylights.set_state(bulbs,0,0,1,0,(500),False)

