# -*- coding: utf-8 -*-
from xml.etree import ElementTree
import xml.etree.ElementTree as ET
import os
import subprocess
import pywapi
import string
from pygeocoder import Geocoder
from address import AddressParser, Address
import commands

'''
Conditions = [
	"Thunderstorm",
	"Thunderstorm",
	"Showers_Cloud",
	"Thunderstorm",
	"Thunderstorm",
	"Sleet",
	"Sleet",
	"Sleet",
	"Sleet",
	"Showers_Cloud",
	"Sleet",
	"Rain",
	"Showers_Cloud",
	"Snow",
	"Snow",
	"Snow",
	"Snow",
	"Hail",
	"Sleet",
	"Fog",
	"Fog",
	"Haze",
	"Fog",
	"Wind",
	"Wind",
	"Frost",
	"Cloud",
	"Mostly Cloudy",
	"Mostly Cloudy",
	"Partly Cloudy",
	"Partly Cloudy",
	"Clear",
	"Clear",
	"Fair",
	"Fair",
	"Sleet",
	"Clear",
	"Thunderstorm",
	"Thunderstorm",
	"Thunderstorm",
	"Showers_cloud",
	"Snow",
	"Snow",
	"Snow",
	"Partlycloudy",
	"Thunderstorm",
	"Snow",
	"Thunderstorm",
	"Blank"];
'''
'''
#with open('/private/var/mobile/Documents/widgetweather.xml', 'rt') as f:
with open('widgetweather.xml', 'rt') as f:
    tree = ElementTree.parse(f)

    
for node in tree.iter('currentcondition'):
    city  = node.findtext('city')
    state = node.findtext('state')
    latitude = node.findtext('latitude')
    longitude = node.findtext('longitude')
    woeid = node.findtext('woeid')
    temp = node.findtext('temp')
    condition = node.findtext('code')
    sunsettime = node.findtext('sunsettime')
    sunrisetime = node.findtext('sunrisetime')
    moonfacevisible = node.findtext('moonfacevisible')
    
ctemp = float(temp)
ftemp = 9.0 / 5.0  * ctemp + 32
'''

for line in file("/var/mobile/Documents/myLocation.txt"):
#for line in file("myLocation.txt"):
    data = [x.strip() for x in line.split('=')]
    if 'Lat' in data:
        lat = float(data[1])
    if 'Long' in data:
        long = float(data[1])
        
#print "Latitude: " + str(lat)
#print "Longitude: " + str(long)

results = Geocoder.reverse_geocode(float(lat), float(long))
#print "Location: "
#print(results[0])
#print results
ap = AddressParser()
address = ap.parse_address(str(results)) 
#print "Address is: {0} ".format(address.zip)
#print address.zip
  
    
#cmd =  "curl --silent \"http://weather.yahooapis.com/forecastrss?w=%s&u=c\" -o /frak/forecast1.txt" % woeid
#cmd = "curl -s -S \'http://weather.yahooapis.com/forecastrss?w=%s&u=c\' | sed \'s/<\\/*br* *\\/*>//gi\'| awk \'/Current Conditions:/ { inWeather = 1 } /href=/ { inWeather = 0 } { if (inWeather) { print $0 } }\'" % woeid
#mycurl = "C:\\Users\\alnaumf\\AppData\\Local\\Atlassian\\SourceTree\\git_local\\bin\\curl.exe --silent "
#mycurl = "curl --silent"
#url = " \"http://where.yahooapis.com/v1/places.q('%s')?appid=YD-9G7bey8_JXxQP6rxl.fBFGgCdNjoDMACQA-- " \'% address.zip
cmd = "curl --silent  \'http://where.yahooapis.com/v1/places.q(\'%s\')?appid=YD-9G7bey8_JXxQP6rxl.fBFGgCdNjoDMACQA--\' " % address.zip
#print cmd
#os.system(cmd) 
results = os.popen(cmd).read()
#with open("stdout.txt","wb") as out:
#	subprocess.Popen(cmd,stdout=out)
#print results

#tree = ElementTree.parse('stdout.txt')
tree = ET.ElementTree(ET.fromstring(results))
root = tree.getroot()
woeid = root[0][0].text
	

#os.system("cat forecast1.txt")

#mycurl = "C:\\Users\\alnaumf\\AppData\\Local\\Atlassian\\SourceTree\\git_local\\bin\\curl.exe -sS "
#mycurl = "curl -s -S"
#url = "http://weather.yahooapis.com/forecastrss?w=1103816&u=c' | sed 's/<\/*br* *\/*>//gi'| awk '/Current Conditions:/ { inWeather = 1 } /href=/ { inWeather = 0 } { if (inWeather) { print $0 } }'" % woeid
#cmd =  mycurl + url
#cmd = "curl -s -S \'http://weather.yahooapis.com/forecastrss?w=%s&u=c\' | sed \'s/<\\/*br* *\\/*>//gi\'| awk \'/Current Conditions:/ { inWeather = 1 } /href=/ { inWeather = 0 } { if (inWeather) { print $0 } }\' " % woeid
#cmd = "curl -s -S \'http://weather.yahooapis.com/forecastrss?w=%s&u=c\' " % woeid
#cmd = "curl -s -S \'http://weather.yahooapis.com/forecastrss?w=%s&u=c\' | sed \'s/<\\/*br* *\\/*>//gi\' " % woeid
cmd = "curl -s -S \"http://weather.yahooapis.com/forecastrss?w=%s&u=c\" -o /frak/forecast.txt" % woeid
#print cmd
os.system(cmd) 
#with open("forecast.txt","wb") as out:
#	subprocess.Popen(cmd,stdout=out)

#results = os.popen(cmd).read()
#print results
     


cmd = "cat /frak/forecast.txt | grep -E \'<yweather:condition\' | sed -e \'s/.*text=\"\\([A-Za-z ]*\\).*/\\1/\'"
desc = commands.getoutput(cmd)

cmd = "cat /frak/forecast.txt | grep -E \'<yweather:condition\' | sed -e \'s/.*temp=\"\\([0-9]*\\).*/\\1/\'"
temp = commands.getoutput(cmd)

ctemp = float(temp)
ftemp = 9.0 / 5.0  * ctemp + 32
ftemp = int(ftemp)

lat = int(lat * 100) / 100.0
long = int(long * 100) / 100.0

s = address.city + ", " + address.state + " " + address.zip + "\n" + "Lat: " + str(lat) + "   Long: " + str(long) + "\nWeather is: " + desc + " " + temp + u"\u00B0 C" + " (" + str(ftemp) +  u"\u00B0 F" +")"
print u'{0}'.format(s).encode('utf-8')

# Sunrise / Sunset
cmd = "cat /frak/forecast.txt | grep -E \'<yweather:astronomy\' | sed -e \'s/.*sunrise=\"\\([0-9: a-z]*\\).*/\\1/\'"
sunrise = commands.getoutput(cmd)
cmd = "cat /frak/forecast.txt | grep -E \'<yweather:astronomy\' | sed -e \'s/.*sunset=\"\\([0-9: a-z]*\\).*/\\1/\'"
sunset = commands.getoutput(cmd)
print "Sunrise:" + sunrise + " Sunset:" + sunset


print("\nForecast:")
cmd = "cat /frak/forecast.txt | grep -E \'<yweather:forecast\' | sed -e \'s/.*day=\"\\([A-Za-z]*\\)\".*low=\"\\([0-9]*\\)\".*high=\"\\([0-9]*\)\".*text=\"\\([A-Za-z ]*\\).*/\\1-\\4. \\3\\/\\2/\'"
#print cmd
temp = commands.getoutput(cmd)
print temp

exit(0)




#string = "Location: %s , %s" % (city,state)
#print string
#cmd="echo "+string
#os.system(cmd)

#string = "Current Temp: " + temp + " C" + " or " + str(ftemp) +  " F"
#cmd="echo "+string
#os.system(cmd)

#string  = "Conditions: " + Conditions[int(condition)]
#cmd="echo "+string
#os.system(cmd)

#os.system("echo Forecast:")
#cmd = "cat /frak/forecast1.txt | grep -E \'<yweather:forecast\' | sed -e \'s/.*day=\"\\([A-Za-z]*\\)\".*low=\"\\([0-9]*\\)\".*high=\"\\([0-9]*\)\".*text=\"\\([A-Za-z ]*\\).*/\\1-\\4. \\3\\/\\2/\';"
#print cmd
#os.system(cmd)
#os.system("echo")
	
#print "Location: " + city + ", " + state
print "Latitude: " + str(lat) + "  Longitude: " + str(long)
#print "woeid: " + woeid
#print "Currently: " + temp 
#s = "Currently: " + temp + u"\u00B0 C" + " or " + str(ftemp) +  u"\u00B0 F"
#print u'{0}'.format(s).encode('utf-8')    
#print "Condition: " + Conditions[int(condition)]
print "Sunset: " + sunsettime + "  Sunrise: " + sunrisetime
print "Moon: " + moonfacevisible + " visible"




'''
yahoo weather:
http://where.yahooapis.com/geocode?location=33.957736,-84.070206&flags=J&gflags=R?appid=YD-9G7bey8_JXxQP6rxl.fBFGgCdNjoDMACQA--
http://where.yahooapis.com/v1/places.q(30044)?appid=YD-9G7bey8_JXxQP6rxl.fBFGgCdNjoDMACQA--

from activate command:
curl -s -S 'http://weather.yahooapis.com/forecastrss?w=1103816&u=c' | sed 's/<\/*br* *\/*>//gi'| awk '/Current Conditions:/ { inWeather = 1 } /href=/ { inWeather = 0 } { if (inWeather) { print $0 } }'

'''