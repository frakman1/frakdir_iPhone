import lazylights
import time

bulbs = lazylights.find_bulbs(expected_bulbs=None, timeout=5)
print bulbs
lazylights.set_power(bulbs, True)
lazylights.set_state(bulbs,240,1,1,0,(500),False)

