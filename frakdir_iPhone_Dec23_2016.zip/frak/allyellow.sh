#!/bin/bash
/bin/echo -e "$(/frak/setcolor.sh 10324 $(shuf -i 33000-65534 -n 1) $(shuf -i 65533-65534 -n 1) 2000 1000)" | socat - udp-datagram:255.255.255.255:56700,broadcast

