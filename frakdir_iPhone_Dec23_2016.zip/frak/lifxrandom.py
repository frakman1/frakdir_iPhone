import os
cmd = "/frak/lifxrandom.sh"
os.system(cmd)

