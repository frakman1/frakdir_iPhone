#!/bin/sh

activator send switch-on.com.a3tweaks.switch.wifi;

sleep 15

if [[ `ifconfig en0 | grep inet` ]] ;then
    echo -e "******************************************************************* CONNECTED ******************************************************";
else
    echo -e "******************************************************************** NOT CONNECTED *************************************************";
    activator send switch-off.com.a3tweaks.switch.wifi;
fi


