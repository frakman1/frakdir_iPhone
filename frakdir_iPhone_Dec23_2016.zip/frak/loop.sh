#!/bin/bash

#/bin/echo -e "$(cat /frak/allgreen.echo)" | socat - udp-datagram:255.255.255.255:56700,broadcast
#for i in $( ls ); do
#            echo item: $i
#        done


#COUNTER=0
         #while [  $COUNTER -lt 10 ]; do
             #echo The counter is $COUNTER
          #   let COUNTER=COUNTER+1 
	    # /bin/echo -e "$(cat /frak/allon.echo)" | socat - udp-datagram:255.255.255.255:56700,broadcast
            # /bin/echo -e "$(cat /frak/alloff.echo)" | socat - udp-datagram:255.255.255.255:56700,broadcast
            #/frak/allred.sh;/frak/allgreen.sh;/frak/allblue.sh;
		
         #done

/frak/allred.sh;sleep 1;
/frak/allblue.sh;sleep 1;
/frak/allgreen.sh;sleep 1;
/frak/allred.sh;sleep 1;
/frak/allblue.sh;sleep 1;
/frak/allgreen.sh;sleep 1;
/frak/allred.sh;sleep 1;
/frak/allblue.sh;sleep 1;
/frak/allgreen.sh;sleep 1;
/frak/allred.sh;sleep 1;
/frak/allblue.sh;sleep 1;
/frak/allgreen.sh;sleep 1;
/frak/allred.sh;sleep 1;
/frak/allblue.sh;sleep 1;
/frak/allgreen.sh;sleep 1;
/frak/allred.sh;sleep 1;
/frak/allblue.sh;sleep 1;
/frak/allgreen.sh;

